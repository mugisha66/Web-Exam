package com.mugisha.SLDonationSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlDonationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
